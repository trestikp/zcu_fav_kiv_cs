package osobni_cislo;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import support.Drivers;
import support.Utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class OsobniCisloStep {


}
