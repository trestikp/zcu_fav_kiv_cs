lex komentare.l
gcc -o komentare lex.yy.c -lfl
./komentare
