<!--
Tom� Rieger A01206
-->
<html>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250" />
  <head>
    <title>
      Implementace p�eklada�e PL/0 v PHP
    </title>
  </head>
  <body>
    <link href="styl.css" type="text/css" rel="stylesheet">
    <h1>Implementace p�eklada�e PL/0 v PHP</h1>
    <b>Vypracoval Tom� Rieger jako semestr�ln� pr�ci z p�ed�mtu KIV/FJP vyu�ovan�m na Z�U.</b><p>
    <form  action="prekladac.php" method="post">
        Zadejte k�d programu k p�elo�en�:<p>
        <textarea name="text" rows="30" cols="50">
        </textarea><p>
        <input type="submit" value="P�elo�it">
    </form>
  </body>
</html>
