This stemmer was taken from https://github.com/RovoMe/PorterStemmer
I DID NOT IMPLEMENT THIS STEMMER NOR DO I OWN IT