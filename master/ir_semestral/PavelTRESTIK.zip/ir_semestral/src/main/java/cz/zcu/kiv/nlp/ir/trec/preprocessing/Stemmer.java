package cz.zcu.kiv.nlp.ir.trec.preprocessing;

/**
 * Created by tigi on 29.2.2016.
 */
public interface Stemmer {
    String stem(String input);
}
