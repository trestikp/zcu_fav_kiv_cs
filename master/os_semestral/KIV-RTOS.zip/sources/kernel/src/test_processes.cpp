#include "../../userspace/build/src_init_task.h"
#include "../../userspace/build/src_sos_task.h"
#include "../../userspace/build/src_oled_task.h"
#include "../../userspace/build/src_logger_task.h"
#include "../../userspace/build/src_counter_task.h"
#include "../../userspace/build/src_tilt_task.h"

// az budeme umet cist SD kartu, tento soubor uplne zmizi
