package game;

/**
 * PlayerStoneColor - color of player or stone
 */
public enum PSColor {
    WHITE, BLACK;
}
