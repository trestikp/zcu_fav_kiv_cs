import graphics.Launcher;

/**
 * Launcher class
 */
public class Main {
    public static void main(String[] args) {
    	Launcher.launch_gui(args);
    }
}

